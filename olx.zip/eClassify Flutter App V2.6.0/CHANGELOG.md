# v2.3.0

## Removed

- _page.link_ usage
- resolved dart analysis warnings
- _lib/utils/responsive_size.dart_

### unused files

- _lib/utils/typedefs.dart_
- _lib/utils/strings.dart_
- _lib/utils/string_extension.dart_
- _lib/utils/star_rating.dart_
- _lib/utils/isolate_data_loader.dart_
- _lib/utils/guestChecker.dart_
- _lib/utils/distance_calculator.dart_
- _lib/utils/deeplinkManager.dart_
- _lib/utils/customRoundedButton.dart_
- _lib/utils/customCircularProgressIndicator.dart_
- _lib/utils/convert.dart_
- _lib/utils/extensions/lib/iterable.dart_
- _lib/utils/extensions/lib/list.dart_
- _lib/utils/extensions/lib/adaptive_type.dart_
- _lib/utils/extensions/lib/map.dart_
- _lib/utils/extensions/lib/num_extension.dart_
- _lib/utils/currency_convertor_